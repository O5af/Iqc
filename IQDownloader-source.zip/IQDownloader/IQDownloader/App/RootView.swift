import SwiftUI

enum AppTab: Hashable {
    case browser, downloads, music, video
}

final class AppState: ObservableObject {
    @Published var selectedTab: AppTab = .browser
}

struct RootView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var downloads: DownloadManager

    var body: some View {
        TabView(selection: $appState.selectedTab) {
            BrowserView()
                .tabItem { Label("المتصفح", systemImage: "globe") }
                .tag(AppTab.browser)

            DownloadsView()
                .tabItem { Label("التحميلات", systemImage: "arrow.down.circle") }
                .badge(downloads.activeCount)
                .tag(AppTab.downloads)

            MusicView()
                .tabItem { Label("الموسيقى", systemImage: "music.note") }
                .tag(AppTab.music)

            VideoView()
                .tabItem { Label("الفيديو", systemImage: "play.rectangle") }
                .tag(AppTab.video)
        }
    }
}
