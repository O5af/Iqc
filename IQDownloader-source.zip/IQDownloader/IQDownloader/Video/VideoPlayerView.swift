import SwiftUI
import AVKit

/// مشغّل الفيديو: AVPlayerViewController (يدعم ملء الشاشة وصورة داخل صورة والصوت في الخلفية).
struct AVPlayerControllerView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = AVPlayer(url: url)
        controller.allowsPictureInPicturePlayback = true
        controller.canStartPictureInPictureAutomaticallyFromInline = true
        controller.player?.play()
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {}

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: ()) {
        controller.player?.pause()
    }
}

struct VideoPlayerScreen: View {
    let file: LibraryFile
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { dismiss() } label: {
                    Label("إغلاق", systemImage: "xmark")
                }
                .foregroundStyle(Color.white)
                Spacer()
                Text(file.displayName)
                    .font(.subheadline)
                    .lineLimit(1)
                    .foregroundStyle(Color.white)
            }
            .padding(.horizontal)
            .padding(.vertical, 10)

            AVPlayerControllerView(url: file.url)
        }
        .background(Color.black.ignoresSafeArea())
        .onAppear { AudioPlayerManager.shared.pause() }
    }
}
