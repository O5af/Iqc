import Foundation

/// يقرأ كل الملفات داخل مجلد Documents الخاص بالتطبيق (وهو ظاهر في تطبيق «الملفات»).
final class FileLibrary: ObservableObject {
    static let shared = FileLibrary()

    @Published private(set) var files: [LibraryFile] = []

    var audioFiles: [LibraryFile] {
        files
            .filter { $0.kind == .audio }
            .sorted { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
    }

    var videoFiles: [LibraryFile] { files.filter { $0.kind == .video } }

    static var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static var downloadsDirectory: URL {
        let dir = documentsDirectory.appendingPathComponent("IQ Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static var supportDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("IQDownloader", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private init() {
        reload()
        NotificationCenter.default.addObserver(forName: .libraryChanged, object: nil, queue: .main) { [weak self] _ in
            self?.reload()
        }
    }

    func reload() {
        _ = Self.downloadsDirectory
        let keys: [URLResourceKey] = [.isRegularFileKey]
        guard let enumerator = FileManager.default.enumerator(
            at: Self.documentsDirectory,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else {
            files = []
            return
        }
        var result: [LibraryFile] = []
        for case let url as URL in enumerator {
            let isFile = (try? url.resourceValues(forKeys: [.isRegularFileKey]))?.isRegularFile ?? false
            if isFile { result.append(LibraryFile(url: url)) }
        }
        files = result.sorted { $0.date > $1.date }
    }

    func delete(_ file: LibraryFile) {
        try? FileManager.default.removeItem(at: file.url)
        reload()
    }
}
