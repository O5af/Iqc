import Foundation

enum DownloadState: String, Codable {
    case downloading
    case paused
    case completed
    case failed
}

struct DownloadItem: Identifiable, Codable, Equatable {
    let id: UUID
    var url: URL
    var fileName: String
    var state: DownloadState
    var bytesWritten: Int64
    var totalBytes: Int64          // -1 = غير معروف
    var localFileName: String?     // اسم الملف داخل مجلد التحميلات (لا نخزّن مسارات مطلقة)
    var errorMessage: String?
    var createdAt: Date

    init(url: URL) {
        self.id = UUID()
        self.url = url
        self.fileName = FileNameTools.name(from: url)
        self.state = .downloading
        self.bytesWritten = 0
        self.totalBytes = -1
        self.localFileName = nil
        self.errorMessage = nil
        self.createdAt = Date()
    }

    var progress: Double {
        guard totalBytes > 0 else { return 0 }
        return min(1, Double(bytesWritten) / Double(totalBytes))
    }
}
