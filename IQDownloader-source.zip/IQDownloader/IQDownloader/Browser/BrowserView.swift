import SwiftUI
import WebKit

struct BrowserView: View {
    @StateObject private var model = BrowserModel()
    @State private var addressText = ""
    @State private var toast: String?
    @FocusState private var addressFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            addressBar
            ZStack {
                WebViewRepresentable(webView: model.webView)
                if !model.hasStarted {
                    HomeView { model.load($0) }
                        .background(Color(.systemBackground))
                }
            }
            bottomBar
        }
        .background(Color(.systemBackground))
        .overlay(alignment: .top) { toastView }
        .confirmationDialog(
            "تحميل ملف",
            isPresented: Binding(
                get: { model.pendingDownload != nil },
                set: { if !$0 { model.pendingDownload = nil } }
            ),
            titleVisibility: .visible,
            presenting: model.pendingDownload
        ) { pending in
            Button("تحميل") {
                model.confirmDownload(pending)
                showToast("بدأ التحميل ✓")
            }
            Button("فتح في المتصفح") { model.openHere(pending) }
            Button("إلغاء", role: .cancel) { }
        } message: { pending in
            Text(pending.suggestedName ?? FileNameTools.name(from: pending.url))
        }
        .onChange(of: model.currentURL) { url in
            if !addressFocused { addressText = url?.absoluteString ?? "" }
        }
    }

    // MARK: - شريط العنوان

    private var addressBar: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: model.currentURL?.scheme == "https" ? "lock.fill" : "globe")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    TextField("ابحث أو أدخل عنوان الموقع", text: $addressText)
                        .focused($addressFocused)
                        .keyboardType(.webSearch)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.go)
                        .onSubmit {
                            addressFocused = false
                            model.load(addressText)
                        }
                    if addressFocused && !addressText.isEmpty {
                        Button { addressText = "" } label: {
                            Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(10)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))

                Menu {
                    Button {
                        model.requestDownload(of: model.currentURL)
                    } label: {
                        Label("تحميل الرابط الحالي", systemImage: "arrow.down.circle")
                    }
                    Button { model.toggleDesktopMode() } label: {
                        Label(model.desktopMode ? "عرض الجوال" : "عرض سطح المكتب", systemImage: "desktopcomputer")
                    }
                    if let url = model.currentURL {
                        ShareLink(item: url) { Label("مشاركة", systemImage: "square.and.arrow.up") }
                        Button {
                            UIPasteboard.general.string = url.absoluteString
                            showToast("تم نسخ الرابط")
                        } label: {
                            Label("نسخ الرابط", systemImage: "doc.on.doc")
                        }
                    }
                    Button(role: .destructive) {
                        model.clearBrowsingData()
                        showToast("تم مسح بيانات التصفح")
                    } label: {
                        Label("مسح بيانات التصفح", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle").font(.title3)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)

            if model.isLoading {
                ProgressView(value: model.progress).progressViewStyle(.linear)
            } else {
                Divider()
            }
        }
    }

    // MARK: - الشريط السفلي

    private var bottomBar: some View {
        HStack {
            Button { model.goBack() } label: { Image(systemName: "chevron.backward") }
                .disabled(!model.canGoBack)
            Spacer()
            Button { model.goForward() } label: { Image(systemName: "chevron.forward") }
                .disabled(!model.canGoForward)
            Spacer()
            Button { model.reloadOrStop() } label: {
                Image(systemName: model.isLoading ? "xmark" : "arrow.clockwise")
            }
            Spacer()
            Button { model.goHome() } label: { Image(systemName: "house") }
        }
        .font(.title3)
        .padding(.horizontal, 28)
        .padding(.vertical, 10)
        .background(.bar)
    }

    // MARK: - تنبيه سريع

    @ViewBuilder private var toastView: some View {
        if let toast {
            Text(toast)
                .font(.subheadline.weight(.medium))
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(.regularMaterial, in: Capsule())
                .padding(.top, 64)
                .transition(.move(edge: .top).combined(with: .opacity))
        }
    }

    private func showToast(_ text: String) {
        withAnimation { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation { toast = nil }
        }
    }
}
