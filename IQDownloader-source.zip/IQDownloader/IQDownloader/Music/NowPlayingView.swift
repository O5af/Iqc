import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject private var audio: AudioPlayerManager
    @State private var dragging = false
    @State private var dragValue: Double = 0

    var body: some View {
        VStack(spacing: 24) {
            Capsule()
                .fill(Color.secondary.opacity(0.4))
                .frame(width: 40, height: 5)
                .padding(.top, 8)

            Spacer(minLength: 0)
            artworkView

            VStack(spacing: 4) {
                Text(audio.title)
                    .font(.title3.bold())
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                if !audio.artist.isEmpty {
                    Text(audio.artist).foregroundStyle(.secondary)
                }
            }

            scrubber
            controls
            Spacer(minLength: 0)
        }
        .padding(24)
    }

    private var artworkView: some View {
        Group {
            if let image = audio.artwork {
                Image(uiImage: image).resizable().scaledToFit()
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: 24)
                        .fill(LinearGradient(colors: [Color.indigo, Color.purple],
                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                    Image(systemName: "music.note")
                        .font(.system(size: 80))
                        .foregroundStyle(Color.white.opacity(0.9))
                }
                .aspectRatio(1, contentMode: .fit)
            }
        }
        .frame(maxWidth: 300, maxHeight: 300)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .shadow(radius: 12, y: 6)
    }

    private var scrubber: some View {
        VStack(spacing: 4) {
            Slider(
                value: Binding(
                    get: { dragging ? dragValue : audio.currentTime },
                    set: { dragValue = $0 }
                ),
                in: 0...max(audio.duration, 1),
                onEditingChanged: { editing in
                    if editing {
                        dragValue = audio.currentTime
                        dragging = true
                    } else {
                        audio.seek(to: dragValue)
                        dragging = false
                    }
                }
            )
            HStack {
                Text(Formatters.duration(dragging ? dragValue : audio.currentTime))
                Spacer()
                Text(Formatters.duration(audio.duration))
            }
            .font(.caption.monospacedDigit())
            .foregroundStyle(.secondary)
        }
        // أشرطة التقديم تبقى من اليسار لليمين حتى في الواجهة العربية
        .environment(\.layoutDirection, .leftToRight)
    }

    private var controls: some View {
        HStack(spacing: 32) {
            Button { audio.shuffle.toggle() } label: {
                Image(systemName: "shuffle")
                    .foregroundStyle(audio.shuffle ? Color.accentColor : Color.secondary)
            }
            .accessibilityLabel("عشوائي")

            Button { audio.previous() } label: { Image(systemName: "backward.fill") }
                .accessibilityLabel("السابق")

            Button { audio.togglePlayPause() } label: {
                Image(systemName: audio.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 64))
            }
            .accessibilityLabel(audio.isPlaying ? "إيقاف مؤقت" : "تشغيل")

            Button { audio.next() } label: { Image(systemName: "forward.fill") }
                .accessibilityLabel("التالي")

            Button { audio.repeatMode = audio.repeatMode.next } label: {
                Image(systemName: audio.repeatMode.symbol)
                    .foregroundStyle(audio.repeatMode == .off ? Color.secondary : Color.accentColor)
            }
            .accessibilityLabel("تكرار")
        }
        .font(.title2)
        .environment(\.layoutDirection, .leftToRight)
    }
}
