import AVFoundation
import UIKit

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        // نمط التشغيل الذي يسمح بالصوت في الخلفية وصورة داخل صورة
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        // إنشاء المدير مبكرًا لإعادة ربط جلسة التحميل في الخلفية
        _ = DownloadManager.shared
        return true
    }

    func application(
        _ application: UIApplication,
        handleEventsForBackgroundURLSession identifier: String,
        completionHandler: @escaping () -> Void
    ) {
        DownloadManager.shared.backgroundCompletionHandler = completionHandler
    }
}
