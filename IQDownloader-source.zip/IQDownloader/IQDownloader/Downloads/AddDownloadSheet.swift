import SwiftUI

struct AddDownloadSheet: View {
    @EnvironmentObject private var downloads: DownloadManager
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var errorText: String?

    private var isEmpty: Bool {
        text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("https://example.com/file.zip", text: $text, axis: .vertical)
                        .lineLimit(1...6)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    PasteButton(payloadType: String.self) { strings in
                        if let first = strings.first { text = first }
                    }
                } header: {
                    Text("رابط أو أكثر (كل رابط في سطر)")
                } footer: {
                    if let errorText {
                        Text(errorText).foregroundStyle(.red)
                    } else {
                        Text("الروابط المباشرة فقط (http أو https).")
                    }
                }
            }
            .navigationTitle("تحميل جديد")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("تحميل") { submit() }.disabled(isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    private func submit() {
        let urls = text
            .split(whereSeparator: \.isNewline)
            .compactMap { URLTools.directURL(from: String($0)) }
        guard !urls.isEmpty else {
            errorText = "لم أجد رابطًا صالحًا. يجب أن يبدأ بـ http أو https."
            return
        }
        for url in urls { downloads.add(url: url) }
        dismiss()
    }
}
