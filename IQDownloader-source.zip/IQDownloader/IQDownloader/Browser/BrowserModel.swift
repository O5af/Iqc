import SwiftUI
import WebKit

struct PendingDownload: Identifiable {
    let id = UUID()
    let url: URL
    let suggestedName: String?
}

/// حالة المتصفح الداخلي + اعتراض روابط الملفات القابلة للتحميل.
final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    let webView: WKWebView

    @Published var currentURL: URL?
    @Published var pageTitle = ""
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var hasStarted = false
    @Published var desktopMode = false
    @Published var pendingDownload: PendingDownload?

    private var observations: [NSKeyValueObservation] = []
    private var allowOnce: URL?

    override init() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.applicationNameForUserAgent = "Version/17.0 Mobile/15E148 Safari/604.1"
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        observe()
    }

    private func observe() {
        observations = [
            webView.observe(\.canGoBack, options: [.new]) { [weak self] _, change in
                self?.canGoBack = change.newValue ?? false
            },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] _, change in
                self?.canGoForward = change.newValue ?? false
            },
            webView.observe(\.isLoading, options: [.new]) { [weak self] _, change in
                self?.isLoading = change.newValue ?? false
            },
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] _, change in
                self?.progress = change.newValue ?? 0
            },
            webView.observe(\.title, options: [.new]) { [weak self] _, change in
                self?.pageTitle = (change.newValue ?? nil) ?? ""
            },
            webView.observe(\.url, options: [.new]) { [weak self] _, change in
                self?.currentURL = change.newValue ?? nil
            }
        ]
    }

    // MARK: - أوامر

    func load(_ input: String) {
        guard let url = URLTools.resolve(input) else { return }
        hasStarted = true
        webView.load(URLRequest(url: url))
    }

    func goBack() {
        hasStarted = true
        if webView.canGoBack { webView.goBack() }
    }

    func goForward() {
        hasStarted = true
        if webView.canGoForward { webView.goForward() }
    }

    func goHome() { hasStarted = false }

    func reloadOrStop() {
        if isLoading { webView.stopLoading() } else { webView.reload() }
    }

    func toggleDesktopMode() {
        desktopMode.toggle()
        webView.reload()
    }

    func requestDownload(of url: URL?) {
        guard let url, URLTools.isWebURL(url) else { return }
        pendingDownload = PendingDownload(url: url, suggestedName: nil)
    }

    func openHere(_ pending: PendingDownload) {
        allowOnce = pending.url
        hasStarted = true
        webView.load(URLRequest(url: pending.url))
    }

    func confirmDownload(_ pending: PendingDownload) {
        let referer = webView.url?.absoluteString
        let target = pending.url
        webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
            let host = target.host ?? ""
            let relevant = cookies.filter { cookie in
                let domain = cookie.domain.hasPrefix(".") ? String(cookie.domain.dropFirst()) : cookie.domain
                return host == domain || host.hasSuffix("." + domain)
            }
            var headers = HTTPCookie.requestHeaderFields(with: relevant)
            if let referer { headers["Referer"] = referer }
            DispatchQueue.main.async {
                DownloadManager.shared.add(url: target, headers: headers)
            }
        }
    }

    func clearBrowsingData() {
        WKWebsiteDataStore.default().removeData(
            ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
            modifiedSince: Date.distantPast
        ) { }
    }

    // MARK: - WKNavigationDelegate

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        preferences: WKWebpagePreferences,
        decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void
    ) {
        preferences.preferredContentMode = desktopMode ? .desktop : .recommended
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow, preferences)
            return
        }
        let scheme = url.scheme?.lowercased() ?? ""
        if !["http", "https", "about", "blob", "data", "javascript"].contains(scheme) {
            UIApplication.shared.open(url)
            decisionHandler(.cancel, preferences)
            return
        }
        let isMainFrame = navigationAction.targetFrame?.isMainFrame ?? true
        if isMainFrame, navigationAction.shouldPerformDownload || URLTools.looksDownloadable(url) {
            if allowOnce == url {
                allowOnce = nil
            } else {
                decisionHandler(.cancel, preferences)
                pendingDownload = PendingDownload(url: url, suggestedName: nil)
                return
            }
        }
        decisionHandler(.allow, preferences)
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationResponse: WKNavigationResponse,
        decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void
    ) {
        guard navigationResponse.isForMainFrame, let url = navigationResponse.response.url else {
            decisionHandler(.allow)
            return
        }
        var isAttachment = false
        if let http = navigationResponse.response as? HTTPURLResponse,
           let disposition = http.value(forHTTPHeaderField: "Content-Disposition")?.lowercased(),
           disposition.contains("attachment") {
            isAttachment = true
        }
        if isAttachment || !navigationResponse.canShowMIMEType {
            decisionHandler(.cancel)
            pendingDownload = PendingDownload(url: url, suggestedName: navigationResponse.response.suggestedFilename)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showError(error)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        showError(error)
    }

    private func showError(_ error: Error) {
        let ns = error as NSError
        // الإلغاء (مثل اعتراض التحميل) ليس خطأً حقيقيًا
        if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { return }
        if ns.domain == "WebKitErrorDomain" { return }
        let message = ns.localizedDescription
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
        let html = """
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head>
        <body dir="rtl" style="font-family:-apple-system;text-align:center;padding:64px 24px;color:#666">
        <h2>تعذّر فتح الصفحة</h2><p>\(message)</p></body></html>
        """
        let failing = ns.userInfo[NSURLErrorFailingURLErrorKey] as? URL
        webView.loadHTMLString(html, baseURL: failing)
    }

    // MARK: - WKUIDelegate

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }

    func webView(
        _ webView: WKWebView,
        runJavaScriptAlertPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping () -> Void
    ) {
        let alert = UIAlertController(title: webView.url?.host, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "حسنًا", style: .default) { _ in completionHandler() })
        present(alert) { completionHandler() }
    }

    func webView(
        _ webView: WKWebView,
        runJavaScriptConfirmPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping (Bool) -> Void
    ) {
        let alert = UIAlertController(title: webView.url?.host, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "موافق", style: .default) { _ in completionHandler(true) })
        present(alert) { completionHandler(false) }
    }

    private func present(_ alert: UIAlertController, fallback: () -> Void) {
        if let controller = UIApplication.topViewController() {
            controller.present(alert, animated: true)
        } else {
            fallback()
        }
    }
}
