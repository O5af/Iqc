import Foundation
import UIKit

extension Notification.Name {
    static let libraryChanged = Notification.Name("IQDownloader.libraryChanged")
}

// MARK: - الروابط

enum URLTools {
    static let downloadableExtensions: Set<String> = [
        "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "iso", "dmg", "pkg", "ipa", "apk", "exe", "msi", "deb",
        "mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "aiff",
        "mp4", "mov", "m4v", "mkv", "avi", "webm", "3gp",
        "doc", "docx", "xls", "xlsx", "ppt", "pptx", "epub", "csv"
    ]

    static func isWebURL(_ url: URL) -> Bool {
        guard let scheme = url.scheme?.lowercased() else { return false }
        return (scheme == "http" || scheme == "https") && url.host != nil
    }

    static func looksDownloadable(_ url: URL) -> Bool {
        guard isWebURL(url) else { return false }
        return downloadableExtensions.contains(url.pathExtension.lowercased())
    }

    /// رابط http/https صالح للتحميل المباشر، أو nil.
    static func directURL(from text: String) -> URL? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, let url = encodedIfNeeded(trimmed), isWebURL(url) else { return nil }
        return url
    }

    /// يحوّل ما كتبه المستخدم في شريط العنوان إلى رابط أو إلى بحث.
    static func resolve(_ input: String) -> URL? {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if let url = directURL(from: text) { return url }
        let looksLikeHost = !text.contains(" ") && text.contains(".") && !text.hasPrefix(".") && !text.hasSuffix(".")
        if looksLikeHost, let url = encodedIfNeeded("https://" + text), isWebURL(url) { return url }
        return searchURL(for: text)
    }

    static func searchURL(for query: String) -> URL? {
        var components = URLComponents(string: "https://www.google.com/search")
        components?.queryItems = [URLQueryItem(name: "q", value: query)]
        return components?.url
    }

    private static func encodedIfNeeded(_ text: String) -> URL? {
        if let url = URL(string: text) { return url }
        var allowed = CharacterSet.urlQueryAllowed
        allowed.formUnion(.urlPathAllowed)
        allowed.formUnion(.urlHostAllowed)
        allowed.insert(charactersIn: "%#")
        return text.addingPercentEncoding(withAllowedCharacters: allowed).flatMap { URL(string: $0) }
    }
}

// MARK: - أسماء الملفات

enum FileNameTools {
    static func sanitize(_ name: String) -> String {
        var illegal = CharacterSet(charactersIn: "/\\:?%*|\"<>")
        illegal.formUnion(.controlCharacters)
        var cleaned = name.components(separatedBy: illegal).joined(separator: "_")
        var trim = CharacterSet.whitespacesAndNewlines
        trim.insert(".")
        cleaned = cleaned.trimmingCharacters(in: trim)
        if cleaned.isEmpty { return "ملف" }
        if cleaned.count > 120 {
            let ns = cleaned as NSString
            let ext = ns.pathExtension
            let base = String((ns.deletingPathExtension as String).prefix(100))
            cleaned = ext.isEmpty ? base : base + "." + String(ext.prefix(10))
        }
        return cleaned
    }

    static func name(from url: URL) -> String {
        let last = url.lastPathComponent
        if last.isEmpty || last == "/" { return sanitize(url.host ?? "download") }
        return sanitize(last.removingPercentEncoding ?? last)
    }

    /// يُرجع مسارًا غير مستخدم داخل المجلد: "اسم (1).ext" ثم "اسم (2).ext" ...
    static func uniqueURL(in directory: URL, name: String, fileManager: FileManager = .default) -> URL {
        var candidate = directory.appendingPathComponent(name)
        guard fileManager.fileExists(atPath: candidate.path) else { return candidate }
        let ext = candidate.pathExtension
        let base = candidate.deletingPathExtension().lastPathComponent
        var index = 1
        while true {
            let newName = ext.isEmpty ? "\(base) (\(index))" : "\(base) (\(index)).\(ext)"
            candidate = directory.appendingPathComponent(newName)
            if !fileManager.fileExists(atPath: candidate.path) { return candidate }
            index += 1
        }
    }
}

// MARK: - تنسيق

enum Formatters {
    static func bytes(_ count: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: count, countStyle: .file)
    }

    static func duration(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "0:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }
}

// MARK: - UIKit

extension UIApplication {
    static func topViewController() -> UIViewController? {
        let scene = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first { $0.activationState == .foregroundActive }
        var top = scene?.windows.first { $0.isKeyWindow }?.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        return top
    }
}
