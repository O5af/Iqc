import SwiftUI

struct MusicView: View {
    @EnvironmentObject private var library: FileLibrary
    @EnvironmentObject private var audio: AudioPlayerManager
    @State private var showNowPlaying = false

    private var tracks: [LibraryFile] { library.audioFiles }

    var body: some View {
        NavigationStack {
            Group {
                if tracks.isEmpty {
                    EmptyStateView(
                        icon: "music.note.list",
                        title: "لا توجد مقاطع صوتية",
                        message: "حمّل ملفات mp3 أو m4a أو غيرها وستظهر هنا تلقائيًا."
                    )
                } else {
                    List {
                        ForEach(tracks) { file in
                            Button { audio.play(file, in: tracks) } label: {
                                TrackRow(
                                    file: file,
                                    isCurrent: audio.currentFile == file,
                                    isPlaying: audio.isPlaying
                                )
                            }
                            .buttonStyle(.plain)
                            .swipeActions {
                                Button(role: .destructive) { library.delete(file) } label: {
                                    Label("حذف", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                    .refreshable { library.reload() }
                }
            }
            .navigationTitle("الموسيقى")
            .safeAreaInset(edge: .bottom) {
                if audio.hasTrack { miniPlayer }
            }
        }
        .sheet(isPresented: $showNowPlaying) { NowPlayingView() }
        .onAppear { library.reload() }
    }

    private var miniPlayer: some View {
        HStack(spacing: 12) {
            Button { showNowPlaying = true } label: {
                HStack(spacing: 12) {
                    Group {
                        if let image = audio.artwork {
                            Image(uiImage: image).resizable().scaledToFill()
                        } else {
                            ZStack {
                                Color.indigo.opacity(0.15)
                                Image(systemName: "music.note").foregroundStyle(Color.indigo)
                            }
                        }
                    }
                    .frame(width: 44, height: 44)
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                    VStack(alignment: .leading, spacing: 2) {
                        Text(audio.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                        if !audio.artist.isEmpty {
                            Text(audio.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                    Spacer()
                }
            }
            .buttonStyle(.plain)

            HStack(spacing: 20) {
                Button { audio.togglePlayPause() } label: {
                    Image(systemName: audio.isPlaying ? "pause.fill" : "play.fill")
                }
                .accessibilityLabel(audio.isPlaying ? "إيقاف مؤقت" : "تشغيل")
                Button { audio.next() } label: { Image(systemName: "forward.fill") }
                    .accessibilityLabel("التالي")
            }
            .font(.title3)
            .environment(\.layoutDirection, .leftToRight)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.regularMaterial)
    }
}

struct TrackRow: View {
    let file: LibraryFile
    let isCurrent: Bool
    let isPlaying: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: isCurrent && isPlaying ? "waveform" : "music.note")
                .frame(width: 28)
                .foregroundStyle(isCurrent ? Color.accentColor : Color.secondary)
            VStack(alignment: .leading, spacing: 2) {
                Text(file.displayName)
                    .lineLimit(1)
                    .foregroundStyle(isCurrent ? Color.accentColor : Color.primary)
                Text(Formatters.bytes(file.size))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .contentShape(Rectangle())
    }
}
