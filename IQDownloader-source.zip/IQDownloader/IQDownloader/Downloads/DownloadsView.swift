import SwiftUI
import QuickLook

struct DownloadsView: View {
    enum Mode: String, CaseIterable, Identifiable {
        case downloads = "التحميلات"
        case files = "الملفات"
        var id: String { rawValue }
    }

    @EnvironmentObject private var downloads: DownloadManager
    @EnvironmentObject private var library: FileLibrary
    @EnvironmentObject private var audio: AudioPlayerManager
    @EnvironmentObject private var appState: AppState

    @State private var mode: Mode = .downloads
    @State private var showAdd = false
    @State private var previewURL: URL?
    @State private var videoToPlay: LibraryFile?

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("القسم", selection: $mode) {
                    ForEach(Mode.allCases) { item in
                        Text(item.rawValue).tag(item)
                    }
                }
                .pickerStyle(.segmented)
                .padding([.horizontal, .top])
                .padding(.bottom, 8)

                switch mode {
                case .downloads: downloadsList
                case .files: filesList
                }
            }
            .navigationTitle("التحميلات")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showAdd = true } label: { Image(systemName: "plus") }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Button { downloads.clearFinished() } label: {
                            Label("مسح المكتملة من القائمة", systemImage: "checkmark.circle")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
        }
        .sheet(isPresented: $showAdd) { AddDownloadSheet() }
        .quickLookPreview($previewURL)
        .fullScreenCover(item: $videoToPlay) { file in VideoPlayerScreen(file: file) }
        .onAppear { library.reload() }
    }

    // MARK: - قائمة التحميلات

    @ViewBuilder private var downloadsList: some View {
        if downloads.items.isEmpty {
            EmptyStateView(
                icon: "arrow.down.circle",
                title: "لا توجد تحميلات",
                message: "اضغط + للصق رابط مباشر، أو حمّل ملفًا من المتصفح."
            )
        } else {
            List {
                ForEach(downloads.items) { item in
                    DownloadRow(item: item) { openCompleted(item) }
                        .swipeActions {
                            Button(role: .destructive) { downloads.remove(item.id) } label: {
                                Label(item.state == .completed ? "إزالة" : "إلغاء", systemImage: "trash")
                            }
                        }
                        .contextMenu {
                            Button {
                                UIPasteboard.general.string = item.url.absoluteString
                            } label: {
                                Label("نسخ الرابط", systemImage: "doc.on.doc")
                            }
                        }
                }
            }
            .listStyle(.plain)
        }
    }

    // MARK: - قائمة الملفات

    @ViewBuilder private var filesList: some View {
        if library.files.isEmpty {
            EmptyStateView(
                icon: "folder",
                title: "لا توجد ملفات",
                message: "الملفات المحمّلة تظهر هنا، وتظهر أيضًا في تطبيق «الملفات» داخل IQ Downloader."
            )
        } else {
            List {
                ForEach(library.files) { file in
                    Button { open(file) } label: { FileRow(file: file) }
                        .buttonStyle(.plain)
                        .swipeActions {
                            Button(role: .destructive) { library.delete(file) } label: {
                                Label("حذف", systemImage: "trash")
                            }
                        }
                        .contextMenu {
                            ShareLink(item: file.url) { Label("مشاركة", systemImage: "square.and.arrow.up") }
                            Button(role: .destructive) { library.delete(file) } label: {
                                Label("حذف", systemImage: "trash")
                            }
                        }
                }
            }
            .listStyle(.plain)
            .refreshable { library.reload() }
        }
    }

    // MARK: - فتح الملفات

    private func openCompleted(_ item: DownloadItem) {
        guard let url = downloads.fileURL(for: item) else { return }
        open(LibraryFile(url: url))
    }

    private func open(_ file: LibraryFile) {
        switch file.kind {
        case .audio:
            audio.play(file, in: library.audioFiles)
            appState.selectedTab = .music
        case .video:
            videoToPlay = file
        case .image, .other:
            previewURL = file.url
        }
    }
}

// MARK: - الصفوف

struct DownloadRow: View {
    let item: DownloadItem
    let onOpen: () -> Void
    @EnvironmentObject private var downloads: DownloadManager

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text(item.fileName).lineLimit(2)
                if item.state == .downloading || item.state == .paused {
                    if item.totalBytes > 0 {
                        ProgressView(value: item.progress)
                    } else if item.state == .downloading {
                        ProgressView().progressViewStyle(.linear)
                    }
                }
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(item.state == .failed ? Color.red : Color.secondary)
                    .lineLimit(2)
            }
            Spacer()
            actionButton
        }
        .contentShape(Rectangle())
        .onTapGesture {
            if item.state == .completed { onOpen() }
        }
    }

    @ViewBuilder private var actionButton: some View {
        switch item.state {
        case .downloading:
            Button { downloads.pause(item.id) } label: { Image(systemName: "pause.circle.fill").font(.title2) }
                .buttonStyle(.borderless)
        case .paused:
            Button { downloads.resume(item.id) } label: { Image(systemName: "play.circle.fill").font(.title2) }
                .buttonStyle(.borderless)
        case .failed:
            Button { downloads.resume(item.id) } label: { Image(systemName: "arrow.clockwise.circle.fill").font(.title2) }
                .buttonStyle(.borderless)
        case .completed:
            Image(systemName: "checkmark.circle.fill").font(.title2).foregroundStyle(Color.green)
        }
    }

    private var subtitle: String {
        switch item.state {
        case .downloading:
            if item.totalBytes > 0 {
                return "\(Formatters.bytes(item.bytesWritten)) من \(Formatters.bytes(item.totalBytes))"
            }
            return Formatters.bytes(item.bytesWritten)
        case .paused:
            return "متوقف مؤقتًا"
        case .completed:
            return Formatters.bytes(item.totalBytes > 0 ? item.totalBytes : item.bytesWritten)
        case .failed:
            return item.errorMessage ?? "فشل التحميل"
        }
    }
}

struct FileRow: View {
    let file: LibraryFile

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .frame(width: 36)
                .foregroundStyle(Color.accentColor)
            VStack(alignment: .leading, spacing: 2) {
                Text(file.name).lineLimit(2)
                Text("\(Formatters.bytes(file.size)) · \(file.date.formatted(date: .abbreviated, time: .omitted))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .contentShape(Rectangle())
    }

    private var icon: String {
        switch file.kind {
        case .audio: return "music.note"
        case .video: return "film"
        case .image: return "photo"
        case .other: return "doc"
        }
    }
}
