import Foundation
import UIKit
import UserNotifications

/// مدير التحميلات: جلسة URLSession في الخلفية (تستمر حتى لو خرجت من التطبيق)،
/// إيقاف مؤقت/استئناف، وحفظ القائمة بين مرات التشغيل.
/// كل الدوال العامة تُستدعى من الخيط الرئيسي.
final class DownloadManager: ObservableObject {
    static let shared = DownloadManager()

    @Published private(set) var items: [DownloadItem] = []
    var backgroundCompletionHandler: (() -> Void)?

    var activeCount: Int { items.filter { $0.state == .downloading }.count }

    private let sessionDelegate = DownloadSessionDelegate()
    private var session: URLSession!
    private var headersByID: [UUID: [String: String]] = [:]
    private var pausing: Set<UUID> = []
    private var removing: Set<UUID> = []
    private var lastTick: [UUID: Date] = [:]
    private var askedForNotifications = false

    private init() {
        items = Self.loadItems()
        let config = URLSessionConfiguration.background(withIdentifier: "iqdownloader.background")
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        config.waitsForConnectivity = true
        config.httpMaximumConnectionsPerHost = 4

        sessionDelegate.onProgress = { [weak self] id, written, total in
            self?.handleProgress(id: id, written: written, total: total)
        }
        sessionDelegate.onFinished = { [weak self] id, fileURL, message in
            self?.handleFinished(id: id, fileURL: fileURL, errorMessage: message)
        }
        sessionDelegate.onTaskCompleted = { [weak self] id, error in
            self?.handleTaskCompleted(id: id, error: error)
        }
        sessionDelegate.onBackgroundEventsFinished = { [weak self] in
            self?.backgroundCompletionHandler?()
            self?.backgroundCompletionHandler = nil
        }
        session = URLSession(configuration: config, delegate: sessionDelegate, delegateQueue: nil)
        reconcile()
    }

    // MARK: - واجهة عامة

    @discardableResult
    func add(url: URL, headers: [String: String] = [:]) -> Bool {
        guard URLTools.isWebURL(url) else { return false }
        requestNotificationPermissionIfNeeded()
        let item = DownloadItem(url: url)
        items.insert(item, at: 0)
        headersByID[item.id] = headers
        startTask(for: item)
        persist()
        return true
    }

    func pause(_ id: UUID) {
        guard let index = position(of: id), items[index].state == .downloading else { return }
        pausing.insert(id)
        items[index].state = .paused
        persist()
        session.getAllTasks { [weak self] tasks in
            guard let task = tasks.first(where: { $0.taskDescription == id.uuidString }) as? URLSessionDownloadTask else { return }
            task.cancel(byProducingResumeData: { data in
                guard let data else { return }
                DispatchQueue.main.async { self?.saveResumeData(data, id) }
            })
        }
    }

    func resume(_ id: UUID) {
        guard !pausing.contains(id),
              let index = position(of: id),
              items[index].state == .paused || items[index].state == .failed else { return }
        items[index].state = .downloading
        items[index].errorMessage = nil
        persist()
        startTask(for: items[index])
    }

    func remove(_ id: UUID) {
        if let index = position(of: id), items[index].state == .downloading {
            removing.insert(id)
            session.getAllTasks { tasks in
                tasks.filter { $0.taskDescription == id.uuidString }.forEach { $0.cancel() }
            }
        }
        items.removeAll { $0.id == id }
        try? FileManager.default.removeItem(at: resumeURL(id))
        headersByID[id] = nil
        persist()
    }

    func clearFinished() {
        items.removeAll { $0.state == .completed }
        persist()
    }

    func fileURL(for item: DownloadItem) -> URL? {
        guard let name = item.localFileName else { return nil }
        let url = FileLibrary.downloadsDirectory.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    // MARK: - المهام

    private func startTask(for item: DownloadItem) {
        let task: URLSessionDownloadTask
        if let data = takeResumeData(item.id) {
            task = session.downloadTask(withResumeData: data)
        } else {
            var request = URLRequest(url: item.url)
            for (key, value) in headersByID[item.id] ?? [:] {
                request.setValue(value, forHTTPHeaderField: key)
            }
            task = session.downloadTask(with: request)
        }
        task.taskDescription = item.id.uuidString
        task.resume()
    }

    /// عند الإقلاع: أي عنصر «قيد التحميل» ليست له مهمة حية يصبح «متوقفًا» ليستأنفه المستخدم.
    private func reconcile() {
        let initialIDs = Set(items.map { $0.id })
        session.getAllTasks { [weak self] tasks in
            let liveIDs = Set(tasks.compactMap { $0.taskDescription.flatMap { UUID(uuidString: $0) } })
            DispatchQueue.main.async {
                guard let self else { return }
                var changed = false
                for index in self.items.indices {
                    let item = self.items[index]
                    if item.state == .downloading, initialIDs.contains(item.id), !liveIDs.contains(item.id) {
                        self.items[index].state = .paused
                        changed = true
                    }
                }
                if changed { self.persist() }
            }
        }
    }

    // MARK: - أحداث الجلسة (على الخيط الرئيسي)

    private func handleProgress(id: UUID, written: Int64, total: Int64) {
        guard let index = position(of: id) else { return }
        let now = Date()
        if let last = lastTick[id], now.timeIntervalSince(last) < 0.3, written != total { return }
        lastTick[id] = now
        items[index].bytesWritten = written
        items[index].totalBytes = total > 0 ? total : -1
    }

    private func handleFinished(id: UUID, fileURL: URL?, errorMessage: String?) {
        pausing.remove(id)
        lastTick[id] = nil
        guard let index = position(of: id) else {
            if fileURL != nil { NotificationCenter.default.post(name: .libraryChanged, object: nil) }
            return
        }
        if let fileURL {
            items[index].state = .completed
            items[index].localFileName = fileURL.lastPathComponent
            items[index].fileName = fileURL.lastPathComponent
            items[index].errorMessage = nil
            if let size = (try? fileURL.resourceValues(forKeys: [.fileSizeKey]))?.fileSize {
                items[index].bytesWritten = Int64(size)
                items[index].totalBytes = Int64(size)
            }
            notifyCompleted(fileURL.lastPathComponent)
            NotificationCenter.default.post(name: .libraryChanged, object: nil)
        } else {
            items[index].state = .failed
            items[index].errorMessage = errorMessage ?? "فشل التحميل"
        }
        persist()
    }

    private func handleTaskCompleted(id: UUID, error: NSError?) {
        guard let error else { return }   // النجاح يصل عبر handleFinished
        let wasPausing = pausing.remove(id) != nil
        let wasRemoving = removing.remove(id) != nil
        if wasRemoving { return }
        if let data = error.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            saveResumeData(data, id)
        }
        guard let index = position(of: id), items[index].state != .completed else { return }
        if error.code == NSURLErrorCancelled && wasPausing {
            items[index].state = .paused
        } else {
            items[index].state = .failed
            items[index].errorMessage = error.localizedDescription
        }
        persist()
    }

    // MARK: - التخزين

    private func position(of id: UUID) -> Int? { items.firstIndex { $0.id == id } }

    private static var itemsFileURL: URL {
        FileLibrary.supportDirectory.appendingPathComponent("downloads.json")
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        try? data.write(to: Self.itemsFileURL, options: .atomic)
    }

    private static func loadItems() -> [DownloadItem] {
        guard let data = try? Data(contentsOf: itemsFileURL),
              let decoded = try? JSONDecoder().decode([DownloadItem].self, from: data) else { return [] }
        return decoded
    }

    private func resumeURL(_ id: UUID) -> URL {
        FileLibrary.supportDirectory.appendingPathComponent("\(id.uuidString).resume")
    }

    private func saveResumeData(_ data: Data, _ id: UUID) {
        try? data.write(to: resumeURL(id), options: .atomic)
    }

    private func takeResumeData(_ id: UUID) -> Data? {
        let url = resumeURL(id)
        guard let data = try? Data(contentsOf: url) else { return nil }
        try? FileManager.default.removeItem(at: url)
        return data
    }

    // MARK: - الإشعارات

    private func requestNotificationPermissionIfNeeded() {
        guard !askedForNotifications else { return }
        askedForNotifications = true
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func notifyCompleted(_ name: String) {
        guard UIApplication.shared.applicationState != .active else { return }
        let content = UNMutableNotificationContent()
        content.title = "اكتمل التحميل"
        content.body = name
        content.sound = .default
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }
}

// MARK: - مفوّض الجلسة (يعمل على خيط خلفي)

final class DownloadSessionDelegate: NSObject, URLSessionDownloadDelegate {
    var onProgress: ((UUID, Int64, Int64) -> Void)?
    var onFinished: ((UUID, URL?, String?) -> Void)?
    var onTaskCompleted: ((UUID, NSError?) -> Void)?
    var onBackgroundEventsFinished: (() -> Void)?

    private static func id(for task: URLSessionTask) -> UUID? {
        guard let text = task.taskDescription else { return nil }
        return UUID(uuidString: text)
    }

    private func report(_ id: UUID, _ url: URL?, _ message: String?) {
        DispatchQueue.main.async { [weak self] in self?.onFinished?(id, url, message) }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard let id = Self.id(for: downloadTask) else { return }
        DispatchQueue.main.async { [weak self] in
            self?.onProgress?(id, totalBytesWritten, totalBytesExpectedToWrite)
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = Self.id(for: downloadTask) else { return }
        if let http = downloadTask.response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            report(id, nil, "رد الخادم برمز الخطأ \(http.statusCode)")
            return
        }
        let fallback = downloadTask.originalRequest?.url.map { FileNameTools.name(from: $0) } ?? "ملف"
        let name = FileNameTools.sanitize(downloadTask.response?.suggestedFilename ?? fallback)
        do {
            let destination = FileNameTools.uniqueURL(in: FileLibrary.downloadsDirectory, name: name)
            try FileManager.default.moveItem(at: location, to: destination)   // يجب أن يتم قبل العودة من الدالة
            report(id, destination, nil)
        } catch {
            report(id, nil, error.localizedDescription)
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = Self.id(for: task) else { return }
        let nsError = error.map { $0 as NSError }
        DispatchQueue.main.async { [weak self] in self?.onTaskCompleted?(id, nsError) }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async { [weak self] in self?.onBackgroundEventsFinished?() }
    }
}
