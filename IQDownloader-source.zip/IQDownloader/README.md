# IQ Downloader

تطبيق iOS (SwiftUI) بواجهة عربية: متصفح داخلي، مدير تحميلات للروابط المباشرة (يعمل في الخلفية)،
مشغّل موسيقى بالخلفية، ومشغّل فيديو (مع صورة داخل صورة).

## البناء بدون Mac
1. أنشئ مستودع GitHub (يفضّل Public لأن دقائق macOS مجانية للمستودعات العامة).
2. ارفع `IQDownloader-source.zip` و`build.yml` من Add file → Upload files.
3. افتح `build.yml` → ✏️ → غيّر اسم الملف إلى `.github/workflows/build.yml` → Commit.
4. تبويب Actions: انتظر اكتمال البناء (≈ 8–15 دقيقة).
5. تبويب Releases: حمّل `IQDownloader.ipa` ثم افتحه عبر SideStore.

## الهيكل
- `project.yml` : تعريف XcodeGen (يولّد مشروع Xcode أثناء البناء)
- `IQDownloader/` : الشيفرة (App, Browser, Downloads, Music, Video, Services, Models, Utilities)
- `IQDownloaderTests/` : اختبارات الوحدة

## ملاحظات
- التحميل للروابط المباشرة فقط. المشغّل الأصلي لا يدعم mkv/avi/webm/ogg/opus.
- ملفاتك تظهر في تطبيق «الملفات» ضمن مجلد IQ Downloader.
