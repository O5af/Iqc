import Foundation

enum MediaKind {
    case audio, video, image, other

    static let audioExtensions: Set<String> = ["mp3", "m4a", "aac", "wav", "flac", "aiff", "aif", "caf", "m4b"]
    static let videoExtensions: Set<String> = ["mp4", "mov", "m4v", "3gp"]
    static let imageExtensions: Set<String> = ["jpg", "jpeg", "png", "gif", "heic", "webp"]

    static func kind(forExtension ext: String) -> MediaKind {
        let e = ext.lowercased()
        if audioExtensions.contains(e) { return .audio }
        if videoExtensions.contains(e) { return .video }
        if imageExtensions.contains(e) { return .image }
        return .other
    }
}

struct LibraryFile: Identifiable, Hashable {
    let url: URL
    let size: Int64
    let date: Date

    var id: URL { url }
    var name: String { url.lastPathComponent }
    var displayName: String { url.deletingPathExtension().lastPathComponent }
    var kind: MediaKind { MediaKind.kind(forExtension: url.pathExtension) }

    init(url: URL) {
        self.url = url
        let values = try? url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        self.size = Int64(values?.fileSize ?? 0)
        self.date = values?.contentModificationDate ?? Date()
    }

    static func == (lhs: LibraryFile, rhs: LibraryFile) -> Bool { lhs.url == rhs.url }
    func hash(into hasher: inout Hasher) { hasher.combine(url) }
}
