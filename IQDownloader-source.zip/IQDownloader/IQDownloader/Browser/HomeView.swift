import SwiftUI

struct QuickLink: Identifiable {
    let id = UUID()
    let title: String
    let icon: String
    let url: String
}

/// صفحة البداية قبل فتح أي موقع.
struct HomeView: View {
    let open: (String) -> Void

    private let links: [QuickLink] = [
        QuickLink(title: "Google", icon: "magnifyingglass", url: "https://www.google.com"),
        QuickLink(title: "DuckDuckGo", icon: "shield", url: "https://duckduckgo.com"),
        QuickLink(title: "ويكيبيديا", icon: "book", url: "https://ar.wikipedia.org"),
        QuickLink(title: "Internet Archive", icon: "archivebox", url: "https://archive.org")
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Image(systemName: "arrow.down.circle.fill")
                    .font(.system(size: 64))
                    .foregroundStyle(Color.indigo)
                    .padding(.top, 40)
                Text("IQ Downloader")
                    .font(.largeTitle.bold())
                Text("تصفّح وحمّل الملفات المباشرة بسهولة")
                    .foregroundStyle(.secondary)

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 12)], spacing: 12) {
                    ForEach(links) { link in
                        Button { open(link.url) } label: {
                            Label(link.title, systemImage: link.icon)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}
