import SwiftUI
import AVFoundation

struct VideoView: View {
    @EnvironmentObject private var library: FileLibrary
    @State private var playing: LibraryFile?

    private var videos: [LibraryFile] { library.videoFiles }

    var body: some View {
        NavigationStack {
            Group {
                if videos.isEmpty {
                    EmptyStateView(
                        icon: "play.rectangle",
                        title: "لا توجد مقاطع فيديو",
                        message: "حمّل ملفات mp4 أو mov أو m4v وستظهر هنا. صيغ mkv وavi وwebm غير مدعومة في مشغّل iOS."
                    )
                } else {
                    List {
                        ForEach(videos) { file in
                            Button { playing = file } label: {
                                HStack(spacing: 12) {
                                    VideoThumbnail(url: file.url)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(file.displayName).lineLimit(2)
                                        Text(Formatters.bytes(file.size))
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .swipeActions {
                                Button(role: .destructive) { library.delete(file) } label: {
                                    Label("حذف", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                    .refreshable { library.reload() }
                }
            }
            .navigationTitle("الفيديو")
        }
        .fullScreenCover(item: $playing) { file in VideoPlayerScreen(file: file) }
        .onAppear { library.reload() }
    }
}

struct VideoThumbnail: View {
    let url: URL
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            Color.black.opacity(0.85)
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "film").foregroundStyle(Color.white.opacity(0.6))
            }
        }
        .frame(width: 96, height: 54)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .task(id: url) { image = await ThumbnailCache.shared.thumbnail(for: url) }
    }
}

final class ThumbnailCache {
    static let shared = ThumbnailCache()
    private let cache = NSCache<NSURL, UIImage>()

    func thumbnail(for url: URL) async -> UIImage? {
        if let cached = cache.object(forKey: url as NSURL) { return cached }
        let generator = AVAssetImageGenerator(asset: AVURLAsset(url: url))
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 320, height: 320)
        do {
            let (cgImage, _) = try await generator.image(at: CMTime(seconds: 1, preferredTimescale: 600))
            let image = UIImage(cgImage: cgImage)
            cache.setObject(image, forKey: url as NSURL)
            return image
        } catch {
            return nil
        }
    }
}
