import XCTest
@testable import IQDownloader

final class UtilitiesTests: XCTestCase {

    // MARK: URLTools

    func testResolveKeepsFullURL() {
        XCTAssertEqual(URLTools.resolve("https://example.com/a.zip")?.absoluteString, "https://example.com/a.zip")
    }

    func testResolveBareHostAddsHTTPS() {
        XCTAssertEqual(URLTools.resolve("example.com")?.absoluteString, "https://example.com")
    }

    func testResolveTextBecomesSearch() {
        let url = URLTools.resolve("swift ui")
        XCTAssertEqual(url?.host, "www.google.com")
        XCTAssertTrue(url?.absoluteString.contains("q=swift") == true)
    }

    func testResolveEmptyIsNil() {
        XCTAssertNil(URLTools.resolve("   "))
    }

    func testDirectURLRejectsNonHTTP() {
        XCTAssertNil(URLTools.directURL(from: "ftp://example.com/a.zip"))
        XCTAssertNil(URLTools.directURL(from: "javascript:alert(1)"))
        XCTAssertNil(URLTools.directURL(from: "not a url"))
        XCTAssertNotNil(URLTools.directURL(from: "  http://example.com/a.mp3  "))
    }

    func testLooksDownloadable() {
        XCTAssertTrue(URLTools.looksDownloadable(URL(string: "https://example.com/a.ZIP")!))
        XCTAssertTrue(URLTools.looksDownloadable(URL(string: "https://example.com/a.mp3")!))
        XCTAssertFalse(URLTools.looksDownloadable(URL(string: "https://example.com/index.html")!))
        XCTAssertFalse(URLTools.looksDownloadable(URL(string: "https://example.com/doc.pdf")!))
    }

    // MARK: FileNameTools

    func testSanitizeReplacesIllegalCharacters() {
        XCTAssertEqual(FileNameTools.sanitize("a/b:c?.zip"), "a_b_c_.zip")
    }

    func testSanitizeEmptyFallsBack() {
        XCTAssertEqual(FileNameTools.sanitize("   "), "ملف")
        XCTAssertEqual(FileNameTools.sanitize("..."), "ملف")
    }

    func testSanitizeLimitsLengthAndKeepsExtension() {
        let long = String(repeating: "a", count: 300) + ".mp3"
        let result = FileNameTools.sanitize(long)
        XCTAssertTrue(result.hasSuffix(".mp3"))
        XCTAssertLessThanOrEqual(result.count, 120)
    }

    func testNameFromURLDecodesPercentEncoding() {
        let url = URL(string: "https://example.com/files/My%20File.zip")!
        XCTAssertEqual(FileNameTools.name(from: url), "My File.zip")
    }

    func testNameFromURLWithoutPathUsesHost() {
        XCTAssertEqual(FileNameTools.name(from: URL(string: "https://example.com/")!), "example.com")
    }

    func testUniqueURLAddsCounter() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: dir) }

        let first = FileNameTools.uniqueURL(in: dir, name: "a.txt")
        XCTAssertEqual(first.lastPathComponent, "a.txt")
        FileManager.default.createFile(atPath: first.path, contents: Data())

        let second = FileNameTools.uniqueURL(in: dir, name: "a.txt")
        XCTAssertEqual(second.lastPathComponent, "a (1).txt")
        FileManager.default.createFile(atPath: second.path, contents: Data())

        XCTAssertEqual(FileNameTools.uniqueURL(in: dir, name: "a.txt").lastPathComponent, "a (2).txt")
    }

    // MARK: MediaKind / Formatters

    func testMediaKind() {
        XCTAssertEqual(MediaKind.kind(forExtension: "mp3"), .audio)
        XCTAssertEqual(MediaKind.kind(forExtension: "MP4"), .video)
        XCTAssertEqual(MediaKind.kind(forExtension: "jpg"), .image)
        XCTAssertEqual(MediaKind.kind(forExtension: "zip"), .other)
    }

    func testDurationFormatting() {
        XCTAssertEqual(Formatters.duration(65), "1:05")
        XCTAssertEqual(Formatters.duration(3661), "1:01:01")
        XCTAssertEqual(Formatters.duration(.nan), "0:00")
    }

    // MARK: DownloadItem

    func testDownloadItemProgress() {
        var item = DownloadItem(url: URL(string: "https://example.com/a.zip")!)
        XCTAssertEqual(item.progress, 0)
        item.bytesWritten = 50
        item.totalBytes = 100
        XCTAssertEqual(item.progress, 0.5, accuracy: 0.0001)
        item.bytesWritten = 500
        XCTAssertEqual(item.progress, 1)
    }

    func testDownloadItemCodableRoundTrip() throws {
        var item = DownloadItem(url: URL(string: "https://example.com/a.zip")!)
        item.state = .paused
        item.bytesWritten = 10
        let data = try JSONEncoder().encode([item])
        let decoded = try JSONDecoder().decode([DownloadItem].self, from: data)
        XCTAssertEqual(decoded, [item])
    }
}
