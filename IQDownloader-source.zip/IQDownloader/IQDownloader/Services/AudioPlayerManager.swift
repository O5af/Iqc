import AVFoundation
import Combine
import MediaPlayer
import UIKit

enum RepeatMode: CaseIterable {
    case off, all, one

    var symbol: String { self == .one ? "repeat.1" : "repeat" }

    var next: RepeatMode {
        switch self {
        case .off: return .all
        case .all: return .one
        case .one: return .off
        }
    }
}

/// مشغّل الموسيقى: يعمل في الخلفية وعلى شاشة القفل (Now Playing + أزرار التحكم عن بعد).
final class AudioPlayerManager: ObservableObject {
    static let shared = AudioPlayerManager()

    @Published private(set) var queue: [LibraryFile] = []
    @Published private(set) var currentIndex: Int?
    @Published private(set) var isPlaying = false
    @Published private(set) var currentTime: Double = 0
    @Published private(set) var duration: Double = 0
    @Published private(set) var title = ""
    @Published private(set) var artist = ""
    @Published private(set) var artwork: UIImage?
    @Published var shuffle = false
    @Published var repeatMode: RepeatMode = .off

    var currentFile: LibraryFile? {
        guard let index = currentIndex, queue.indices.contains(index) else { return nil }
        return queue[index]
    }

    var hasTrack: Bool { currentFile != nil }

    private let player = AVPlayer()
    private var cancellables = Set<AnyCancellable>()
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?
    private var userPaused = false

    private init() {
        timeObserver = player.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.5, preferredTimescale: 600),
            queue: .main
        ) { [weak self] time in
            guard let self else { return }
            if time.seconds.isFinite { self.currentTime = time.seconds }
        }

        player.publisher(for: \.timeControlStatus)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] status in
                guard let self else { return }
                self.isPlaying = status != .paused
                self.updateNowPlaying()
            }
            .store(in: &cancellables)

        setupRemoteCommands()
        observeInterruptions()
    }

    // MARK: - التحكم

    func play(_ file: LibraryFile, in files: [LibraryFile]) {
        queue = files.contains(file) ? files : [file]
        load(index: queue.firstIndex(of: file) ?? 0)
    }

    func pause() {
        userPaused = true
        player.pause()
    }

    func resume() {
        guard hasTrack else { return }
        userPaused = false
        activateSession()
        player.play()
    }

    func togglePlayPause() {
        if isPlaying { pause() } else { resume() }
    }

    func next() { advance(auto: false) }

    func previous() {
        guard let index = currentIndex else { return }
        if currentTime > 3 || index == 0 {
            seek(to: 0)
        } else {
            load(index: index - 1)
        }
    }

    func seek(to seconds: Double) {
        let target = max(0, seconds)
        currentTime = target
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600)) { [weak self] _ in
            DispatchQueue.main.async { self?.updateNowPlaying() }
        }
    }

    // MARK: - داخلي

    private func load(index: Int) {
        guard queue.indices.contains(index) else { return }
        currentIndex = index
        let file = queue[index]
        let item = AVPlayerItem(url: file.url)

        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in self?.trackEnded() }

        title = file.displayName
        artist = ""
        artwork = nil
        duration = 0
        currentTime = 0
        userPaused = false

        player.replaceCurrentItem(with: item)
        activateSession()
        player.play()
        updateNowPlaying()
        loadMetadata(for: file)
    }

    private func advance(auto: Bool) {
        guard let index = currentIndex, !queue.isEmpty else { return }
        if shuffle, queue.count > 1 {
            var candidate = index
            while candidate == index { candidate = Int.random(in: 0..<queue.count) }
            load(index: candidate)
        } else if index + 1 < queue.count {
            load(index: index + 1)
        } else if repeatMode == .all || !auto {
            load(index: 0)
        } else {
            userPaused = true
            player.pause()
            seek(to: 0)
        }
    }

    private func trackEnded() {
        if repeatMode == .one {
            seek(to: 0)
            player.play()
        } else {
            advance(auto: true)
        }
    }

    private func activateSession() {
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func loadMetadata(for file: LibraryFile) {
        let url = file.url
        Task { [weak self] in
            let asset = AVURLAsset(url: url)
            var newTitle: String?
            var newArtist: String?
            var newArtwork: UIImage?
            var newDuration: Double = 0
            do {
                let length = try await asset.load(.duration)
                if length.seconds.isFinite { newDuration = length.seconds }
                let metadata = try await asset.load(.commonMetadata)
                for item in metadata {
                    guard let key = item.commonKey else { continue }
                    if key == .commonKeyTitle {
                        newTitle = try await item.load(.stringValue)
                    } else if key == .commonKeyArtist {
                        newArtist = try await item.load(.stringValue)
                    } else if key == .commonKeyArtwork {
                        if let data = try await item.load(.dataValue) { newArtwork = UIImage(data: data) }
                    }
                }
            } catch {
                // نكتفي بالاسم المأخوذ من الملف
            }
            let titleValue = newTitle
            let artistValue = newArtist
            let artworkValue = newArtwork
            let durationValue = newDuration
            await MainActor.run {
                guard let self, self.currentFile?.url == url else { return }
                if let titleValue, !titleValue.isEmpty { self.title = titleValue }
                if let artistValue { self.artist = artistValue }
                self.artwork = artworkValue
                self.duration = durationValue
                self.updateNowPlaying()
            }
        }
    }

    private func updateNowPlaying() {
        guard hasTrack else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: title,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: currentTime,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
        if !artist.isEmpty { info[MPMediaItemPropertyArtist] = artist }
        if let image = artwork {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func setupRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.isEnabled = true
        center.pauseCommand.isEnabled = true
        center.togglePlayPauseCommand.isEnabled = true
        center.nextTrackCommand.isEnabled = true
        center.previousTrackCommand.isEnabled = true
        center.changePlaybackPositionCommand.isEnabled = true

        center.playCommand.addTarget { [weak self] _ in self?.resume(); return .success }
        center.pauseCommand.addTarget { [weak self] _ in self?.pause(); return .success }
        center.togglePlayPauseCommand.addTarget { [weak self] _ in self?.togglePlayPause(); return .success }
        center.nextTrackCommand.addTarget { [weak self] _ in self?.next(); return .success }
        center.previousTrackCommand.addTarget { [weak self] _ in self?.previous(); return .success }
        center.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            self?.seek(to: event.positionTime)
            return .success
        }
    }

    private func observeInterruptions() {
        NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification, object: nil, queue: .main
        ) { [weak self] note in
            guard let self,
                  let rawType = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: rawType),
                  type == .ended else { return }
            let rawOptions = note.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            let options = AVAudioSession.InterruptionOptions(rawValue: rawOptions)
            if options.contains(.shouldResume), !self.userPaused, self.hasTrack {
                self.player.play()
            }
        }
    }
}
